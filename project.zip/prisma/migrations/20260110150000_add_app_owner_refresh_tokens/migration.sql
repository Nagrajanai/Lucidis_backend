-- CreateTable
CREATE TABLE IF NOT EXISTS "app_owner_refresh_tokens" (
    "id" TEXT NOT NULL,
    "appOwnerId" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "app_owner_refresh_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "app_owner_refresh_tokens_token_key" ON "app_owner_refresh_tokens"("token");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "app_owner_refresh_tokens_appOwnerId_idx" ON "app_owner_refresh_tokens"("appOwnerId");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "app_owner_refresh_tokens_token_idx" ON "app_owner_refresh_tokens"("token");

-- AddForeignKey
ALTER TABLE "app_owner_refresh_tokens" ADD CONSTRAINT "app_owner_refresh_tokens_appOwnerId_fkey" FOREIGN KEY ("appOwnerId") REFERENCES "app_owners"("id") ON DELETE CASCADE ON UPDATE CASCADE;
