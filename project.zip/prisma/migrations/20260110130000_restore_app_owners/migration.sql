-- Restore app_owners table and revert isAppOwner changes

-- Drop RLS policies that depend on appOwnerId
DROP POLICY IF EXISTS "accounts_isolation_policy" ON "accounts";

-- Create app_owners table
CREATE TABLE IF NOT EXISTS "app_owners" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT NOT NULL,
    "name" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "app_owners_pkey" PRIMARY KEY ("id")
);

-- Create unique index
CREATE UNIQUE INDEX IF NOT EXISTS "app_owners_email_key" ON "app_owners"("email");

-- Migrate existing AppOwners (users with isAppOwner = true) to app_owners table
INSERT INTO "app_owners" ("id", "email", "password", "name", "createdAt", "updatedAt")
SELECT 
    "id",
    "email",
    "password",
    COALESCE("firstName" || ' ' || "lastName", "firstName", "lastName", '') as "name",
    "createdAt",
    "updatedAt"
FROM "users"
WHERE "isAppOwner" = true
ON CONFLICT ("id") DO NOTHING;

-- Update accounts.appOwnerId to reference app_owners.id
-- First, ensure all appOwnerIds in accounts exist in app_owners
-- If not, we'll need to create them or handle the migration

-- Drop foreign key constraint
ALTER TABLE "accounts" DROP CONSTRAINT IF EXISTS "accounts_appOwnerId_fkey";

-- Update accounts to reference app_owners
-- Note: This assumes all accounts.appOwnerId values correspond to users with isAppOwner = true
-- If not, you may need to handle this differently

-- Add foreign key constraint to app_owners
ALTER TABLE "accounts" ADD CONSTRAINT "accounts_appOwnerId_fkey" 
    FOREIGN KEY ("appOwnerId") REFERENCES "app_owners"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- Remove isAppOwner column from users table
ALTER TABLE "users" DROP COLUMN IF EXISTS "isAppOwner";

-- Recreate RLS policies with app_owners table
CREATE POLICY "accounts_isolation_policy" ON accounts
  FOR ALL
  USING (
    id IN (
      SELECT "accountId" FROM account_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
    OR 
    "appOwnerId"::text IN (
      SELECT id::text FROM app_owners 
      WHERE email = current_setting('app.current_user_email', true)
    )
  );
