-- Enable Row-Level Security on all tenant tables
ALTER TABLE accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE workspaces ENABLE ROW LEVEL SECURITY;
ALTER TABLE departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE teams ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;
ALTER TABLE messages ENABLE ROW LEVEL SECURITY;
ALTER TABLE account_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE workspace_users ENABLE ROW LEVEL SECURITY;
ALTER TABLE team_users ENABLE ROW LEVEL SECURITY;

-- Drop existing policies if they exist
DROP POLICY IF EXISTS "accounts_isolation_policy" ON accounts;
DROP POLICY IF EXISTS "workspaces_isolation_policy" ON workspaces;
DROP POLICY IF EXISTS "departments_isolation_policy" ON departments;
DROP POLICY IF EXISTS "teams_isolation_policy" ON teams;
DROP POLICY IF EXISTS "conversations_isolation_policy" ON conversations;
DROP POLICY IF EXISTS "messages_isolation_policy" ON messages;
DROP POLICY IF EXISTS "account_users_isolation_policy" ON account_users;
DROP POLICY IF EXISTS "workspace_users_isolation_policy" ON workspace_users;
DROP POLICY IF EXISTS "team_users_isolation_policy" ON team_users;

-- RLS Policy: Accounts - Users can only see accounts they belong to or own
CREATE POLICY "accounts_isolation_policy" ON accounts
  FOR ALL
  USING (
    id IN (
      SELECT "accountId" FROM account_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
    OR 
    "appOwnerId"::text IN (
      SELECT id::text FROM app_owners 
      WHERE email = current_setting('app.current_user_email', true)
    )
  );

-- RLS Policy: Workspaces - Users can only see workspaces in their accounts
CREATE POLICY "workspaces_isolation_policy" ON workspaces
  FOR ALL
  USING (
    -- Workspace belongs to account user has access to
    "accountId" IN (
      SELECT "accountId" FROM account_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
    AND
    -- User is member of this workspace (or account admin can see all)
    (
      id IN (
        SELECT "workspaceId" FROM workspace_users 
        WHERE "userId"::text = current_setting('app.current_user_id', true)
      )
      OR
      "accountId" IN (
        SELECT "accountId" FROM account_users 
        WHERE "userId"::text = current_setting('app.current_user_id', true)
        AND role = 'ADMIN'
      )
    )
  );

-- RLS Policy: Departments - Scoped to workspace
CREATE POLICY "departments_isolation_policy" ON departments
  FOR ALL
  USING (
    "workspaceId" IN (
      SELECT "workspaceId" FROM workspace_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
  );

-- RLS Policy: Teams - Scoped to department (which is scoped to workspace)
CREATE POLICY "teams_isolation_policy" ON teams
  FOR ALL
  USING (
    "departmentId" IN (
      SELECT d.id FROM departments d
      INNER JOIN workspace_users wu ON d."workspaceId" = wu."workspaceId"
      WHERE wu."userId"::text = current_setting('app.current_user_id', true)
    )
  );

-- RLS Policy: Conversations - Scoped to workspace
CREATE POLICY "conversations_isolation_policy" ON conversations
  FOR ALL
  USING (
    "workspaceId" IN (
      SELECT "workspaceId" FROM workspace_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
  );

-- RLS Policy: Messages - Scoped via conversation to workspace
CREATE POLICY "messages_isolation_policy" ON messages
  FOR ALL
  USING (
    "conversationId" IN (
      SELECT c.id FROM conversations c
      INNER JOIN workspace_users wu ON c."workspaceId" = wu."workspaceId"
      WHERE wu."userId"::text = current_setting('app.current_user_id', true)
    )
  );

-- RLS Policy: Account Users - Users can only see their own account memberships
CREATE POLICY "account_users_isolation_policy" ON account_users
  FOR ALL
  USING (
    "userId"::text = current_setting('app.current_user_id', true)
    OR
    "accountId" IN (
      SELECT "accountId" FROM account_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
  );

-- RLS Policy: Workspace Users - Scoped to workspace
CREATE POLICY "workspace_users_isolation_policy" ON workspace_users
  FOR ALL
  USING (
    "workspaceId" IN (
      SELECT "workspaceId" FROM workspace_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
  );

-- RLS Policy: Team Users - Scoped via team to workspace
CREATE POLICY "team_users_isolation_policy" ON team_users
  FOR ALL
  USING (
    "teamId" IN (
      SELECT t.id FROM teams t
      INNER JOIN departments d ON t."departmentId" = d.id
      INNER JOIN workspace_users wu ON d."workspaceId" = wu."workspaceId"
      WHERE wu."userId"::text = current_setting('app.current_user_id', true)
    )
  );

