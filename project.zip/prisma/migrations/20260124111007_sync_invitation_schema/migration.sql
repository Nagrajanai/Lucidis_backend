/*
  Warnings:

  - Made the column `appOwnerId` on table `accounts` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "department_users_departmentId_idx";

-- DropIndex
DROP INDEX "department_users_userId_idx";

-- AlterTable
ALTER TABLE "accounts" ALTER COLUMN "appOwnerId" SET NOT NULL;
