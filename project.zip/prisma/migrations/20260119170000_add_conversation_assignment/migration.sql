-- AlterTable
ALTER TABLE "conversations" ADD COLUMN IF NOT EXISTS "assignedUserId" TEXT;
ALTER TABLE "conversations" ADD COLUMN IF NOT EXISTS "assignedAt" TIMESTAMP(3);

-- CreateIndex
CREATE INDEX IF NOT EXISTS "conversations_assignedUserId_idx" ON "conversations"("assignedUserId");

-- AddForeignKey
ALTER TABLE "conversations" ADD CONSTRAINT "conversations_assignedUserId_fkey" FOREIGN KEY ("assignedUserId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
