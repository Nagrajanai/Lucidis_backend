-- CreateEnum
CREATE TYPE "DepartmentRole" AS ENUM ('DEPARTMENT_MANAGER', 'HUMAN_SUPPORT', 'MEMBER');

-- CreateTable
CREATE TABLE IF NOT EXISTS "department_users" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "departmentId" TEXT NOT NULL,
    "role" "DepartmentRole" NOT NULL DEFAULT 'MEMBER',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "department_users_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX IF NOT EXISTS "department_users_userId_departmentId_key" ON "department_users"("userId", "departmentId");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "department_users_userId_idx" ON "department_users"("userId");

-- CreateIndex
CREATE INDEX IF NOT EXISTS "department_users_departmentId_idx" ON "department_users"("departmentId");

-- AddForeignKey
ALTER TABLE "department_users" ADD CONSTRAINT "department_users_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "department_users" ADD CONSTRAINT "department_users_departmentId_fkey" FOREIGN KEY ("departmentId") REFERENCES "departments"("id") ON DELETE CASCADE ON UPDATE CASCADE;
