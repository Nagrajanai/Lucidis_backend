-- CreateEnum
CREATE TYPE "InvitationScope" AS ENUM ('ACCOUNT', 'WORKSPACE', 'DEPARTMENT', 'TEAM');

-- CreateEnum
CREATE TYPE "InvitationStatus" AS ENUM ('INVITED', 'ACCEPTED', 'EXPIRED');

-- CreateEnum
CREATE TYPE "MembershipStatus" AS ENUM ('INVITED', 'ACTIVE', 'REMOVED');

-- CreateTable
CREATE TABLE "invitations" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "accountId" TEXT NOT NULL,
    "invitedByUserId" TEXT NOT NULL,
    "scope" "InvitationScope" NOT NULL,
    "targetId" TEXT,
    "role" TEXT NOT NULL,
    "status" "InvitationStatus" NOT NULL DEFAULT 'INVITED',
    "tokenHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "invitations_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "invitations_email_idx" ON "invitations"("email");

-- CreateIndex
CREATE INDEX "invitations_accountId_idx" ON "invitations"("accountId");

-- CreateIndex
CREATE INDEX "invitations_tokenHash_idx" ON "invitations"("tokenHash");

-- CreateIndex
CREATE INDEX "invitations_status_idx" ON "invitations"("status");

-- AddForeignKey
ALTER TABLE "invitations" ADD CONSTRAINT "invitations_accountId_fkey" FOREIGN KEY ("accountId") REFERENCES "accounts"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "invitations" ADD CONSTRAINT "invitations_invitedByUserId_fkey" FOREIGN KEY ("invitedByUserId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AlterTable: account_users
-- Make userId nullable
ALTER TABLE "account_users" ALTER COLUMN "userId" DROP NOT NULL;

-- Add new columns with defaults
ALTER TABLE "account_users" ADD COLUMN "email" TEXT;
ALTER TABLE "account_users" ADD COLUMN "status" "MembershipStatus" NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE "account_users" ADD COLUMN "invitationId" TEXT;

-- Update existing records to ensure status is ACTIVE (already default, but explicit)
UPDATE "account_users" SET "status" = 'ACTIVE' WHERE "status" IS NULL;

-- Create indexes
CREATE INDEX "account_users_email_idx" ON "account_users"("email");
CREATE INDEX "account_users_status_idx" ON "account_users"("status");

-- Drop existing unique constraint and recreate as partial index
ALTER TABLE "account_users" DROP CONSTRAINT IF EXISTS "account_users_userId_accountId_key";
DROP INDEX IF EXISTS "account_users_userId_accountId_key";
CREATE UNIQUE INDEX "account_users_userId_accountId_key" ON "account_users"("userId", "accountId");

-- Add unique constraint for email + accountId (partial index)
CREATE UNIQUE INDEX "account_users_email_accountId_key" ON "account_users"("email", "accountId");

-- AddForeignKey
ALTER TABLE "account_users" ADD CONSTRAINT "account_users_invitationId_fkey" FOREIGN KEY ("invitationId") REFERENCES "invitations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AlterTable: workspace_users
-- Make userId nullable
ALTER TABLE "workspace_users" ALTER COLUMN "userId" DROP NOT NULL;

-- Add new columns with defaults
ALTER TABLE "workspace_users" ADD COLUMN "email" TEXT;
ALTER TABLE "workspace_users" ADD COLUMN "status" "MembershipStatus" NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE "workspace_users" ADD COLUMN "invitationId" TEXT;

-- Update existing records to ensure status is ACTIVE
UPDATE "workspace_users" SET "status" = 'ACTIVE' WHERE "status" IS NULL;

-- Create indexes
CREATE INDEX "workspace_users_email_idx" ON "workspace_users"("email");
CREATE INDEX "workspace_users_status_idx" ON "workspace_users"("status");

-- Drop existing unique constraint and recreate as partial index
ALTER TABLE "workspace_users" DROP CONSTRAINT IF EXISTS "workspace_users_userId_workspaceId_key";
DROP INDEX IF EXISTS "workspace_users_userId_workspaceId_key";
CREATE UNIQUE INDEX "workspace_users_userId_workspaceId_key" ON "workspace_users"("userId", "workspaceId");

-- Add unique constraint for email + workspaceId (partial index)
CREATE UNIQUE INDEX "workspace_users_email_workspaceId_key" ON "workspace_users"("email", "workspaceId");

-- AddForeignKey
ALTER TABLE "workspace_users" ADD CONSTRAINT "workspace_users_invitationId_fkey" FOREIGN KEY ("invitationId") REFERENCES "invitations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AlterTable: department_users
-- Make userId nullable
ALTER TABLE "department_users" ALTER COLUMN "userId" DROP NOT NULL;

-- Add new columns with defaults
ALTER TABLE "department_users" ADD COLUMN "email" TEXT;
ALTER TABLE "department_users" ADD COLUMN "status" "MembershipStatus" NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE "department_users" ADD COLUMN "invitationId" TEXT;

-- Update existing records to ensure status is ACTIVE
UPDATE "department_users" SET "status" = 'ACTIVE' WHERE "status" IS NULL;

-- Create indexes
CREATE INDEX "department_users_email_idx" ON "department_users"("email");
CREATE INDEX "department_users_status_idx" ON "department_users"("status");

-- Drop existing unique constraint and recreate as partial index
ALTER TABLE "department_users" DROP CONSTRAINT IF EXISTS "department_users_userId_departmentId_key";
DROP INDEX IF EXISTS "department_users_userId_departmentId_key";
CREATE UNIQUE INDEX "department_users_userId_departmentId_key" ON "department_users"("userId", "departmentId");

-- Add unique constraint for email + departmentId (partial index)
CREATE UNIQUE INDEX "department_users_email_departmentId_key" ON "department_users"("email", "departmentId");

-- AddForeignKey
ALTER TABLE "department_users" ADD CONSTRAINT "department_users_invitationId_fkey" FOREIGN KEY ("invitationId") REFERENCES "invitations"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AlterTable: team_users
-- Make userId nullable
ALTER TABLE "team_users" ALTER COLUMN "userId" DROP NOT NULL;

-- Add new columns with defaults
ALTER TABLE "team_users" ADD COLUMN "email" TEXT;
ALTER TABLE "team_users" ADD COLUMN "status" "MembershipStatus" NOT NULL DEFAULT 'ACTIVE';
ALTER TABLE "team_users" ADD COLUMN "invitationId" TEXT;

-- Update existing records to ensure status is ACTIVE
UPDATE "team_users" SET "status" = 'ACTIVE' WHERE "status" IS NULL;

-- Create indexes
CREATE INDEX "team_users_email_idx" ON "team_users"("email");
CREATE INDEX "team_users_status_idx" ON "team_users"("status");

-- Drop existing unique constraint and recreate as partial index
ALTER TABLE "team_users" DROP CONSTRAINT IF EXISTS "team_users_userId_teamId_key";
DROP INDEX IF EXISTS "team_users_userId_teamId_key";
CREATE UNIQUE INDEX "team_users_userId_teamId_key" ON "team_users"("userId", "teamId");

-- Add unique constraint for email + teamId (partial index)
CREATE UNIQUE INDEX "team_users_email_teamId_key" ON "team_users"("email", "teamId");

-- AddForeignKey
ALTER TABLE "team_users" ADD CONSTRAINT "team_users_invitationId_fkey" FOREIGN KEY ("invitationId") REFERENCES "invitations"("id") ON DELETE SET NULL ON UPDATE CASCADE;