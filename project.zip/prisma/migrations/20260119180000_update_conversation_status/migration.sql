-- AlterEnum: Update ConversationStatus enum
-- This migration updates the ConversationStatus enum and adds statusUpdatedAt field

-- Step 1: Add new statusUpdatedAt column
ALTER TABLE "conversations" ADD COLUMN IF NOT EXISTS "statusUpdatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP;

-- Step 2: Create new enum type (use lowercase to match PostgreSQL behavior)
CREATE TYPE conversationstatus_new AS ENUM ('TODO', 'ASSIGNED', 'ESCALATED', 'CLOSED');

-- Step 3: Drop the default value temporarily
ALTER TABLE "conversations" ALTER COLUMN "status" DROP DEFAULT;

-- Step 4: Alter column to use new enum (with data mapping)
ALTER TABLE "conversations" ALTER COLUMN "status" TYPE conversationstatus_new USING (
  CASE "status"::text
    WHEN 'OPEN' THEN 'TODO'::conversationstatus_new
    WHEN 'PENDING' THEN 'TODO'::conversationstatus_new
    WHEN 'RESOLVED' THEN 'CLOSED'::conversationstatus_new
    WHEN 'CLOSED' THEN 'CLOSED'::conversationstatus_new
    ELSE 'TODO'::conversationstatus_new
  END
);

-- Step 5: Drop old enum and rename new one
DROP TYPE "ConversationStatus";
ALTER TYPE conversationstatus_new RENAME TO "ConversationStatus";

-- Step 6: Set new default value
ALTER TABLE "conversations" ALTER COLUMN "status" SET DEFAULT 'TODO';

-- Step 7: Add index on status for inbox queries
CREATE INDEX IF NOT EXISTS "conversations_status_idx" ON "conversations"("status");
