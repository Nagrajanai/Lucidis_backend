-- Migration: Remove app_owners table and use isAppOwner flag in users table

-- Step 1: Add isAppOwner column to users table
ALTER TABLE users ADD COLUMN IF NOT EXISTS "isAppOwner" BOOLEAN NOT NULL DEFAULT false;

-- Step 2: Migrate existing app_owners data to users table
-- Update users table to set isAppOwner = true for users that exist in app_owners
UPDATE users 
SET "isAppOwner" = true 
WHERE email IN (SELECT email FROM app_owners);

-- Step 3: Drop RLS policy that depends on appOwnerId column
DROP POLICY IF EXISTS "accounts_isolation_policy" ON accounts;

-- Step 4: Update accounts table to reference users.id instead of app_owners.id
-- First, we need to create a temporary column
ALTER TABLE accounts ADD COLUMN IF NOT EXISTS "appOwnerId_new" TEXT;

-- Update the new column with user IDs from app_owners
UPDATE accounts a
SET "appOwnerId_new" = u.id::text
FROM app_owners ao, users u
WHERE a."appOwnerId" = ao.id::text
AND ao.email = u.email;

-- Drop the old foreign key constraint
ALTER TABLE accounts DROP CONSTRAINT IF EXISTS "accounts_appOwnerId_fkey";

-- Drop old column (CASCADE to drop dependent objects)
ALTER TABLE accounts DROP COLUMN IF EXISTS "appOwnerId" CASCADE;

-- Rename new column
ALTER TABLE accounts RENAME COLUMN "appOwnerId_new" TO "appOwnerId";

-- Add new foreign key constraint to users table
ALTER TABLE accounts 
ADD CONSTRAINT "accounts_appOwnerId_fkey" 
FOREIGN KEY ("appOwnerId") 
REFERENCES users(id) 
ON DELETE CASCADE;

-- Step 5: Recreate RLS policy with updated logic
CREATE POLICY "accounts_isolation_policy" ON accounts
  FOR ALL
  USING (
    -- User is member of this account
    id IN (
      SELECT "accountId" FROM account_users 
      WHERE "userId"::text = current_setting('app.current_user_id', true)
    )
    OR 
    -- User is owner of this account (check via users table with isAppOwner flag)
    "appOwnerId"::text = current_setting('app.current_user_id', true)
  );

-- Step 6: Drop app_owners table
DROP TABLE IF EXISTS app_owners CASCADE;

